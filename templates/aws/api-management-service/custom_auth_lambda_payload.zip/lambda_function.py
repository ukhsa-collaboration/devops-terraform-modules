import json

HARDCODED_TOKEN = "3JmKoWSvbnBhay8sitjPo1SjmZMKlydeMoradeyosTUoDxzwyaCICqqudFXrgpj9klN4AtizBsRav"

def lambda_handler(event, context):
    print(event)
    # Retrieve the authToken from the event
    # For a REQUEST type authorizer, the token is in the headers
    token = event['headers'].get('authToken', None)

    # Check if the token matches the hardcoded token
    if token == HARDCODED_TOKEN:
        # Allow the request
        return generate_policy("user", "Allow", event["methodArn"])
    else:
        # Deny the request
        return generate_policy("user", "Deny", event["methodArn"])

def generate_policy(principal_id, effect, resource):
    authResponse = {}
    authResponse["principalId"] = principal_id
    if effect and resource:
        policyDocument = {
            "Version": "2012-10-17",
            "Statement": [{
                "Action": "execute-api:Invoke",
                "Effect": effect,
                "Resource": resource
            }]
        }
        authResponse["policyDocument"] = policyDocument
    return authResponse
