exports.handler = async (event, context, callback) => {
    console.log(event);
    if (!event.request.userAttributes.email.endsWith("ukhsa.gov.uk")) {
        var error = new Error("Only UKHSA Email accounts can register.");
        callback(error, event);
    }
    callback(null, event);
};
